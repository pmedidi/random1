public enum DiscountType {
    PERCENTAGE,
    AMOUNT;
}
