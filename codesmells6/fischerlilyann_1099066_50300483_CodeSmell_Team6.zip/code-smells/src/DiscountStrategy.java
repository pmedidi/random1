public interface DiscountStrategy {
    double calculateDiscountedPrice(double price, double discountAmount);
}
