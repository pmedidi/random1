public interface EmailService {
    void sendEmail(String customerEmail, String subject, String message);
}
