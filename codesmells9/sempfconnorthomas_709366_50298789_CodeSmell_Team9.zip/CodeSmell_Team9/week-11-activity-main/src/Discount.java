public abstract class Discount {
    public abstract double calculateDiscount(double price);
    public abstract DiscountType getDiscountType();
}

