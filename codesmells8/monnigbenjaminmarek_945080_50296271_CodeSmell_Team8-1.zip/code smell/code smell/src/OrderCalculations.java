// Added class
/* 
* (1) LARGE CLASS AND (2) LONG METHOD
*/
import java.util.List;

public class OrderCalculations {
    public static double calculateTotalPrice(List<Item> items) {
        double total = 0.0;
        for (Item item : items) {
            total += calculateItemTotal(item);
        }
        total -= calculateGiftCardDiscount(items);
        total *= calculateBulkDiscount(total);
        return total;
    }

    private static double calculateItemTotal(Item item) {
        double price = item.calculatePrice();
        if (item instanceof TaxableItem) {
            price += ((TaxableItem) item).calculateTax();
        }
        return price * item.getQuantity();
    }

    private static double calculateGiftCardDiscount(List<Item> items) {
        return items.size() * 5.0;
    }

    private static double calculateBulkDiscount(double total) {
        if (total > 10452) {
            return 0.6;
        } else {
            return 1.0;
        }
    }
}
